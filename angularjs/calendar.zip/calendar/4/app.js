var myApp = angular.module("myApp", ['ngRoute']);

// .value('Name','Value');

myApp.config( ['$routeProvider',
	function ($routeProvider) {
	$routeProvider
		.when('/', 
			{ controller: 'ComplexController', templateUrl: 'view.html'})
		.when('/:eventId', 
			{ controller: 'ComplexController', templateUrl: 'view.html'})
		.when('/events', 
			{ controller: 'SimpleController', templateUrl: 'list_view.html'})
		.when('/events/:eventId', 
			{ controller: 'DetailController', templateUrl: 'detail_view.html'})
		.otherwise( { redirectTo: '/' });
}]);

/*
//Add this to have access to a global variable
app.run(function ($rootScope, $window) {
    $rootScope.events = $window.events; //global variable
});
*/

myApp.controller('SimpleController', ['$scope', '$window', function ($scope, $window) {
	$scope.events = $window.events;

	$scope.message = "I am the SimpleController";
}]);

myApp.controller('DetailController', ['$scope', '$window', '$routeParams', function ($scope, $window, $routeParams) {
	$scope.events = $window.events;
	$scope.eventId = $routeParams.eventId;
	
	$scope.eventItem = _.find($scope.events.items, function(obj) { return obj.id == $scope.eventId })
	
	$scope.message = "I am the DetailController";

	
}]);

myApp.controller('ComplexController', ['$scope', '$window', '$routeParams', function ($scope, $window, $routeParams) {
	$scope.events = $window.events;
	$scope.eventId = $routeParams.eventId;
	
	$scope.eventItem = _.find($scope.events.items, function(obj) { return obj.id == $scope.eventId })
	
	$scope.message = "I am the ComplexController";

	
}]);
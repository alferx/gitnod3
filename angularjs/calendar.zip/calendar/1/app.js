var myApp = angular.module("myApp", []);

myApp.controller('SimpleController', ['$scope', '$window', function ($scope, $window) {
	$scope.events = $window.events;
}]);
var myApp = angular.module("myApp", ['ngRoute', 'ngResource']);

// .value('Name','Value');

myApp.config( ['$routeProvider',
	function ($routeProvider) {
	$routeProvider
		.when('/', 
			{ controller: 'EventListCtrl', templateUrl: 'view.html'})
		.when('/events/:eventId', 
			{ controller: 'EventDetailsCtrl', templateUrl: 'view.html'})
		.otherwise( { redirectTo: '/' });
}]);

myApp.factory( 'simpleFactory', function ($resource) {

//	'https://www.googleapis.com/calendar/v3/calendars/10q59njl08i8dj5dl0argclaf0%40group.calendar.google.com/events',
//	{key: 'AIzaSyC-WAzgRR-WP6rTZsIKvoJxMCTp3k0Wrkw'}, 
	
	return $resource(
	'https://www.googleapis.com/calendar/v3/calendars/sviciu@gmail.com/events/',
	{}, 
	{
		query:  {method:'GET', isArray:false, headers: {'Authorization': 'Bearer ya29.1.AADtN_VmC0KX6iPQWwLBVfozn9LaiIw9tRY3-A_PX2ZWHEhsIQ_bjePVaHCnDU_xhiA4LLDvElocFr-pkj2o'} }, 
		save: {method:'POST', headers: {'Authorization': 'Bearer ya29.1.AADtN_VmC0KX6iPQWwLBVfozn9LaiIw9tRY3-A_PX2ZWHEhsIQ_bjePVaHCnDU_xhiA4LLDvElocFr-pkj2o'} }
	}
	);

});

/*
myApp.service('EventsList', ['$rootScope', function($rootScope) {
	this.get = function() {
	}
});

myApp.controller('EventListCtrl', ['$scope', 'EventList', function($scope, EventList) {
	$scope.events = EventList.get();
	$scope.$on('EventList', function (event, data) {
		$scope.events = data;
	});
}]);
*/

myApp.controller('EventListCtrl', ['$scope', '$rootScope', 'simpleFactory', function ($scope, $rootScope, simpleFactory) {
		$rootScope.events = simpleFactory.query();		// it is now a resource
		$scope.message = "I am the EventListCtrl";
}]);

myApp.controller('EventDetailsCtrl', ['$scope', '$rootScope', '$routeParams', '$location', 'simpleFactory', function ($scope, $rootScope, $routeParams, $location, simpleFactory) {

	$scope.eventId = $routeParams.eventId;
	
	if(!$rootScope.events) { $location = $location.path("/"); return; }
	
	$scope.idx = 0;
	$scope.eventItem = _.find($rootScope.events.items, function(obj) { return obj.id == $scope.eventId || ++$scope.idx == $rootScope.events.items.length && ($scope.idx = -1); })
	
	$scope.message = "I am the EventDetailsController";

	/*
	// bind to some button ng-click
	console.log('saving event');
		simpleFactory.save({
			"end": { "dateTime": "2014-01-27T10:30:00+01:00" },
			"start": { "dateTime": "2014-01-27T09:30:00+01:00" }
		});
	*/
	
}]);

